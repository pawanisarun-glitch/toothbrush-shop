/**
 * Google Apps Script ผูกกับ Google Sheet (ชีตชื่อ "Order")
 * หัวคอลัมน์ต้องเป็น (แถวที่ 1):
 * Order_ID | Timestamp | Costumer_Name | Phone | Address | Item_JSON | Total_Price | Status
 * ตั้งค่า Script Properties: SECRET = รหัสลับเดียวกับ APPS_SCRIPT_SECRET ใน Vercel
 */
const SHEET_NAME = 'Order';

function doPost(e) {
  const body = JSON.parse(e.postData.contents);
  if (body.secret !== PropertiesService.getScriptProperties().getProperty('SECRET')) {
    return out({ ok: false, error: 'unauthorized' });
  }
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const sh = SpreadsheetApp.getActive().getSheetByName(SHEET_NAME);
    if (body.action === 'create') return out(createOrder(sh, body.order));
    if (body.action === 'list') return out({ ok: true, orders: listOrders(sh) });
    if (body.action === 'status') return out(setStatus(sh, body.ids, body.status));
    return out({ ok: false, error: 'bad action' });
  } finally {
    lock.releaseLock();
  }
}

function createOrder(sh, o) {
  const day = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyMMdd');
  const id = 'TB' + day + '-' + ('000' + sh.getLastRow()).slice(-4);
  const row = sh.getLastRow() + 1;
  sh.getRange(row, 4).setNumberFormat('@'); // กันเลข 0 หน้าเบอร์โทรหาย
  sh.getRange(row, 1, 1, 8).setValues([[
    id, new Date(), o.name, o.phone, o.address,
    JSON.stringify(o.items), o.total, 'New'
  ]]);
  return { ok: true, orderId: id };
}

function listOrders(sh) {
  const v = sh.getDataRange().getValues();
  const head = v.shift();
  return v.filter(r => r[0]).map(r => {
    const o = {};
    head.forEach((h, i) => { o[h] = r[i] instanceof Date ? r[i].toISOString() : String(r[i]); });
    return o;
  });
}

function setStatus(sh, ids, status) {
  const col = sh.getRange(1, 1, sh.getLastRow(), 1).getValues().map(r => r[0]);
  let n = 0;
  ids.forEach(id => {
    const i = col.indexOf(id);
    if (i > 0) { sh.getRange(i + 1, 8).setValue(status); n++; }
  });
  return { ok: true, updated: n };
}

function out(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
