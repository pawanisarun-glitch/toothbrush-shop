// เรียก Google Apps Script (ซ่อน URL และรหัสลับไว้ฝั่งเซิร์ฟเวอร์)
module.exports = async function callSheet(payload) {
  const r = await fetch(process.env.APPS_SCRIPT_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify({ ...payload, secret: process.env.APPS_SCRIPT_SECRET }),
    redirect: 'follow'
  });
  return r.json();
};
