const callSheet = require('./_gs');

// ใช้ได้เฉพาะแอดมิน (ต้องส่งรหัส ADMIN_KEY ใน header)
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  if (!process.env.ADMIN_KEY || req.headers['x-admin-key'] !== process.env.ADMIN_KEY) {
    return res.status(401).json({ ok: false, error: 'รหัสไม่ถูกต้อง' });
  }
  try {
    const b = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    if (b.action === 'list') return res.json(await callSheet({ action: 'list' }));
    if (b.action === 'status' && Array.isArray(b.ids) && ['New', 'Packed', 'Shipped'].includes(b.status)) {
      return res.json(await callSheet({ action: 'status', ids: b.ids, status: b.status }));
    }
    res.status(400).json({ ok: false, error: 'bad request' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: 'ระบบขัดข้อง' });
  }
};
