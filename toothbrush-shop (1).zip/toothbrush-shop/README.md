# ร้านแปรงสีฟัน — Landing Page + ระบบหยิบ/แพ็ค/ใบปะหน้า

โครงสร้าง
- `index.html` หน้าขายสินค้า (อ่านสินค้าจาก `products.json`)
- `admin.html` หน้าแอดมิน: ใบหยิบสินค้า, ใบแพ็ค, ใบปะหน้าพัสดุ 100x150 มม., อัปเดตสถานะ
- `api/order.js` รับออเดอร์ → คำนวณราคาใหม่ฝั่งเซิร์ฟเวอร์ → เขียนลง Google Sheet
- `api/orders.js` ดึงออเดอร์/อัปเดตสถานะ (ต้องมี ADMIN_KEY)
- `apps-script/Code.gs` โค้ดที่วางใน Google Apps Script ของ Sheet
- `images/` โฟลเดอร์รูปสินค้า (ตอนนี้เป็นรูปตัวอย่าง ให้เปลี่ยนเป็นรูปจริง)

## ขั้นตอนติดตั้ง
1. **Google Sheet**: เปิดไฟล์ `Toothbrush_Order.xlsx` ใน Google Sheets (ชีตชื่อ `Order`, หัวคอลัมน์แถวแรกเหมือนเดิมทุกตัว รวมถึง `Costumer_Name`)
2. **Apps Script**: ใน Sheet เลือก Extensions → Apps Script → วางโค้ดจาก `apps-script/Code.gs`
   - Project Settings → Script Properties → เพิ่ม `SECRET` = รหัสลับยาวๆ ที่คุณตั้งเอง
   - Deploy → New deployment → Web app → Execute as: **Me**, Who has access: **Anyone** → คัดลอก URL `/exec`
3. **GitHub**: สร้าง repo แล้ว push ไฟล์ทั้งหมดในโฟลเดอร์นี้ (รวม `images/`)
4. **Vercel**: Add New Project → เลือก repo → Framework: Other → ใส่ Environment Variables
   - `APPS_SCRIPT_URL` = URL ข้อ 2
   - `APPS_SCRIPT_SECRET` = ค่าเดียวกับ `SECRET`
   - `ADMIN_KEY` = รหัสเข้าหน้า admin → กด Deploy
5. เปิด `https://<โดเมนของคุณ>.vercel.app/` เพื่อสั่งซื้อ และ `/admin.html` เพื่อจัดการออเดอร์

## ปรับแต่ง
- แก้ชื่อร้าน/ที่อยู่ผู้ส่ง/ค่าส่ง/สินค้า ใน `products.json` (เพิ่ม SKU ได้ไม่จำกัด)
- ทุกครั้งที่แก้ Code.gs ต้อง Deploy → Manage deployments → New version
- สถานะออเดอร์: `New` → `Packed` → `Shipped`
