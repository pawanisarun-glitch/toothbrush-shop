const fs = require('fs');
const path = require('path');
const callSheet = require('./_gs');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false, error: 'method' });
  try {
    const b = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    if (b.website) return res.status(200).json({ ok: true, orderId: 'OK' }); // honeypot กันบอท

    const cfg = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'products.json'), 'utf8'));
    const name = String(b.name || '').trim().slice(0, 100);
    const phone = String(b.phone || '').replace(/\D/g, '');
    const address = String(b.address || '').trim().slice(0, 400);
    if (!name || !/^0\d{8,9}$/.test(phone) || address.length < 10) {
      return res.status(400).json({ ok: false, error: 'กรุณากรอกชื่อ เบอร์โทร และที่อยู่ให้ครบถ้วน' });
    }

    // คำนวณราคาใหม่ฝั่งเซิร์ฟเวอร์จาก products.json (ไม่เชื่อราคาจากหน้าเว็บ)
    const items = [];
    let subtotal = 0;
    for (const it of (Array.isArray(b.items) ? b.items : [])) {
      const p = cfg.products.find(x => x.sku === it.sku);
      const qty = Math.floor(Number(it.qty));
      if (!p || !(qty >= 1 && qty <= 50)) continue;
      items.push({ sku: p.sku, name: p.name, qty, price: p.price });
      subtotal += p.price * qty;
    }
    if (!items.length) return res.status(400).json({ ok: false, error: 'ยังไม่ได้เลือกสินค้า' });
    const shipping = subtotal >= cfg.freeShippingOver ? 0 : cfg.shipping;

    const r = await callSheet({
      action: 'create',
      order: { name, phone, address, items, total: subtotal + shipping }
    });
    if (!r.ok) throw new Error(r.error || 'sheet error');
    res.status(200).json({ ok: true, orderId: r.orderId, total: subtotal + shipping });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: 'ระบบขัดข้อง กรุณาลองใหม่อีกครั้ง' });
  }
};
