/**
 * วางโค้ดนี้ใน Google Sheet: Extensions > Apps Script
 * แล้ว Deploy > New deployment > Web app (Execute as: Me, Access: Anyone)
 */
const CFG = {
  sheet: 'Orders',
  shipFee: 40, freeShipOver: 300,
  sender: {name: 'ชื่อร้านของคุณ', phone: '0xx-xxx-xxxx', addr: 'ที่อยู่ร้านผู้ส่ง ถนน แขวง เขต จังหวัด รหัสไปรษณีย์'},
  products: {   // SKU ต้องตรงกับ index.html (ราคาคิดจากฝั่งนี้เสมอ)
    'TB-SOFT-01': {name: 'Soft Care ขนนุ่มพิเศษ', price: 89},
    'TB-CHAR-02': {name: 'Charcoal Clean ชาร์โคล', price: 99}
  }
};
const HEAD = ['OrderID','เวลา','ชื่อผู้รับ','โทร','ที่อยู่','แขวง/ตำบล','เขต/อำเภอ','จังหวัด','รหัสไปรษณีย์',
  'SKU','สินค้า','จำนวน','ราคา/ชิ้น','ค่าส่ง','ยอดรวมออเดอร์','ชำระเงิน','หมายเหตุ','สถานะ'];
const C = {id:0,name:2,phone:3,addr:4,sub:5,dist:6,prov:7,zip:8,sku:9,item:10,qty:11,total:14,pay:15,note:16,status:17};

function sheet_() {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(CFG.sheet);
  if (!sh) { sh = ss.insertSheet(CFG.sheet); sh.appendRow(HEAD); sh.setFrozenRows(1); }
  return sh;
}
function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

// ---------- รับออเดอร์จากเว็บ ----------
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const d = JSON.parse(e.postData.contents);
    if (d.website) return json_({ok: true, orderId: '-', total: 0}); // กันบอท
    for (const k of ['name','phone','address','subdistrict','district','province','zip']) {
      if (!String(d[k] || '').trim()) return json_({ok: false, error: 'กรอกข้อมูลไม่ครบ'});
    }
    const phone = String(d.phone).replace(/\D/g, '');
    const zip = String(d.zip).replace(/\D/g, '');
    if (!/^0\d{8,9}$/.test(phone) || !/^\d{5}$/.test(zip)) return json_({ok: false, error: 'เบอร์โทรหรือรหัสไปรษณีย์ไม่ถูกต้อง'});

    const lines = [];
    let sub = 0;
    for (const sku in (d.items || {})) {
      const p = CFG.products[sku], q = Math.floor(Number(d.items[sku]));
      if (!p || !(q > 0) || q > 20) continue;
      lines.push({sku, name: p.name, price: p.price, qty: q});
      sub += p.price * q;
    }
    if (!lines.length) return json_({ok: false, error: 'ไม่พบสินค้าในออเดอร์'});

    const ship = sub >= CFG.freeShipOver ? 0 : CFG.shipFee;
    const total = sub + ship;
    const now = new Date();
    const orderId = 'TB' + Utilities.formatDate(now, 'Asia/Bangkok', 'yyMMddHHmmss');
    const rows = lines.map(l => [orderId, now, d.name.trim(), phone, d.address.trim(), d.subdistrict.trim(),
      d.district.trim(), d.province.trim(), zip, l.sku, l.name, l.qty, l.price, ship, total,
      d.payment || '', (d.note || '').trim(), 'ใหม่']);

    const sh = sheet_();
    const start = sh.getLastRow() + 1;
    sh.getRange(start, C.phone + 1, rows.length, 1).setNumberFormat('@');
    sh.getRange(start, C.zip + 1, rows.length, 1).setNumberFormat('@');
    sh.getRange(start, 1, rows.length, HEAD.length).setValues(rows);
    return json_({ok: true, orderId, total});
  } catch (err) {
    return json_({ok: false, error: 'ระบบขัดข้อง'});
  } finally {
    lock.releaseLock();
  }
}

// ---------- เมนูในชีต ----------
function onOpen() {
  SpreadsheetApp.getUi().createMenu('📦 แพ็คสินค้า')
    .addItem('1) สร้างใบหยิบสินค้า (PickList)', 'makePickList')
    .addItem('2) พิมพ์ใบปะหน้าพัสดุ', 'showLabels')
    .addItem('3) ทำเครื่องหมาย "แพ็คแล้ว"', 'markPacked')
    .addToUi();
}
function newRows_() {
  const v = sheet_().getDataRange().getValues();
  v.shift();
  return v.filter(r => r[C.status] === 'ใหม่');
}

function makePickList() {
  const rows = newRows_();
  const t = {};
  rows.forEach(r => {
    t[r[C.sku]] = t[r[C.sku]] || {name: r[C.item], qty: 0};
    t[r[C.sku]].qty += Number(r[C.qty]);
  });
  const ss = SpreadsheetApp.getActive();
  const sh = ss.getSheetByName('PickList') || ss.insertSheet('PickList');
  sh.clear();
  const orders = new Set(rows.map(r => r[C.id])).size;
  const data = [['SKU', 'สินค้า', 'จำนวนที่ต้องหยิบ', 'หยิบแล้ว ✓']]
    .concat(Object.keys(t).map(k => [k, t[k].name, t[k].qty, '']));
  data.push(['', 'รวม ' + orders + ' ออเดอร์', rows.reduce((s, r) => s + Number(r[C.qty]), 0), '']);
  sh.getRange(1, 1, data.length, 4).setValues(data);
  sh.getRange(1, 1, 1, 4).setFontWeight('bold').setBackground('#d9f2ec');
  sh.getRange(data.length, 1, 1, 4).setFontWeight('bold');
  sh.getRange(2, 4, data.length - 1, 1).insertCheckboxes();
  sh.autoResizeColumns(1, 4);
  ss.setActiveSheet(sh);
}

function showLabels() {
  const rows = newRows_();
  if (!rows.length) { SpreadsheetApp.getUi().alert('ไม่มีออเดอร์สถานะ "ใหม่"'); return; }
  const o = {};
  rows.forEach(r => {
    const id = r[C.id];
    o[id] = o[id] || {r, items: []};
    o[id].items.push(r[C.sku] + ' ×' + r[C.qty]);
  });
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
  const s = CFG.sender;
  const labels = Object.keys(o).map(id => {
    const r = o[id].r, cod = String(r[C.pay]).indexOf('COD') >= 0;
    return `<div class="l">
      <div class="from">ผู้ส่ง: ${esc(s.name)} โทร ${esc(s.phone)}<br>${esc(s.addr)}</div>
      <div class="to"><b>ผู้รับ: ${esc(r[C.name])}</b> โทร ${esc(r[C.phone])}<br>
        ${esc(r[C.addr])} ${esc(r[C.sub])} ${esc(r[C.dist])}<br>${esc(r[C.prov])} <b class="zip">${esc(r[C.zip])}</b></div>
      <div class="it">${esc(id)}<br>${o[id].items.map(esc).join(' , ')}${r[C.note] ? '<br>หมายเหตุ: ' + esc(r[C.note]) : ''}</div>
      ${cod ? `<div class="cod">เก็บเงินปลายทาง ${esc(r[C.total])} บาท</div>` : ''}
    </div>`;
  }).join('');
  const html = `<style>
    body{font-family:sans-serif;margin:0}
    .l{width:100mm;height:150mm;box-sizing:border-box;border:1px dashed #999;padding:5mm;page-break-after:always;font-size:12pt}
    .from{font-size:9pt;border-bottom:1px solid #000;padding-bottom:3mm;margin-bottom:3mm}
    .to{font-size:14pt;line-height:1.5}.zip{font-size:20pt}
    .it{margin-top:4mm;font-size:10pt;border-top:1px solid #000;padding-top:2mm}
    .cod{margin-top:4mm;border:2px solid #000;text-align:center;font-weight:bold;font-size:16pt;padding:2mm}
    .bar{padding:8px;background:#eee}@media print{.bar{display:none}.l{border:0}}
    @page{size:100mm 150mm;margin:0}
  </style><div class="bar"><button onclick="window.print()">🖨 พิมพ์ (${Object.keys(o).length} ใบ)</button></div>${labels}`;
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutput(html).setWidth(520).setHeight(640), 'ใบปะหน้าพัสดุ');
}

function markPacked() {
  const ui = SpreadsheetApp.getUi();
  if (ui.alert('เปลี่ยนสถานะ "ใหม่" ทั้งหมดเป็น "แพ็คแล้ว"?', ui.ButtonSet.YES_NO) !== ui.Button.YES) return;
  const sh = sheet_(), v = sh.getDataRange().getValues();
  for (let i = 1; i < v.length; i++) if (v[i][C.status] === 'ใหม่') sh.getRange(i + 1, C.status + 1).setValue('แพ็คแล้ว');
}
