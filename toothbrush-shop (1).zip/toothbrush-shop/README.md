# ร้านแปรงสีฟัน (Landing page + Google Sheet + Vercel)

## โครงสร้าง
- index.html        หน้าเว็บขายสินค้า (static)
- images/           รูปสินค้า
- apps-script/Code.gs  โค้ดวางใน Google Sheet

## ขั้นตอน
1. สร้าง Google Sheet ใหม่ > Extensions > Apps Script > วาง Code.gs (แก้ CFG.sender เป็นที่อยู่ร้าน)
2. Deploy > New deployment > Web app: Execute as = Me, Who has access = Anyone > คัดลอก URL
3. วาง URL ใน index.html ที่ `API_URL` และปรับชื่อ/ราคา/รูปสินค้าให้ตรงกับ CFG.products
4. อัปโหลดรูปเข้าโฟลเดอร์ images/
5. `git init && git add . && git commit -m "init" && git push` ขึ้น GitHub
6. vercel.com > Add New Project > Import repo (Framework: Other) > Deploy
7. ผูกโดเมน: Project > Settings > Domains

## วันแพ็คของ (เมนู 📦 ใน Google Sheet)
1. สร้างใบหยิบสินค้า -> ได้ยอดรวมแต่ละ SKU
2. พิมพ์ใบปะหน้าพัสดุ (ขนาด 100x150 mm, มียอด COD)
3. ทำเครื่องหมาย "แพ็คแล้ว"
> ถ้าแก้ Code.gs ภายหลัง ต้อง Deploy > Manage deployments > New version
